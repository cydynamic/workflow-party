#!/usr/bin/env node

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { randomUUID } = require('node:crypto');
const { spawnSync } = require('node:child_process');

const SCHEMA_VERSION = 1;
const PACKAGE_VERSION = require('../package.json').version;
const LOCAL_GIT_COMMIT_IDENTITY = {
  name: 'KaleidoSphere Local',
  email: 'local@kaleidosphere.invalid'
};

function resolveKsHome(args) {
  const homeIndex = args.indexOf('--home');
  if (homeIndex !== -1) {
    const configuredHome = args[homeIndex + 1];
    if (!configuredHome || configuredHome.startsWith('--')) {
      throw new Error('--home requires a directory path');
    }
    return path.resolve(configuredHome);
  }

  return path.resolve(process.env.KS_HOME || path.join(os.homedir(), '.ks'));
}

function writeJsonIfMissing(filePath, value) {
  if (fs.existsSync(filePath)) {
    return false;
  }

  const temporaryPath = `${filePath}.${process.pid}.${Date.now()}.tmp`;
  try {
    fs.writeFileSync(temporaryPath, `${JSON.stringify(value, null, 2)}\n`, { flag: 'wx' });
    fs.renameSync(temporaryPath, filePath);
    return true;
  } catch (error) {
    fs.rmSync(temporaryPath, { force: true });
    if (error.code === 'EEXIST' && fs.existsSync(filePath)) {
      return false;
    }
    throw error;
  }
}

function writeJson(filePath, value) {
  const temporaryPath = `${filePath}.${process.pid}.${Date.now()}.tmp`;
  try {
    fs.writeFileSync(temporaryPath, `${JSON.stringify(value, null, 2)}\n`, { flag: 'wx' });
    fs.renameSync(temporaryPath, filePath);
  } catch (error) {
    fs.rmSync(temporaryPath, { force: true });
    throw error;
  }
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function option(args, name, required = false) {
  const index = args.indexOf(name);
  const value = index === -1 ? undefined : args[index + 1];
  if (required && (!value || value.startsWith('--'))) {
    throw new Error(`${name} requires a value`);
  }
  return value;
}

function initialize(home) {
  const registryPath = path.join(home, 'registry');
  fs.mkdirSync(registryPath, { recursive: true });
  fs.mkdirSync(path.join(home, 'state'), { recursive: true });
  fs.mkdirSync(path.join(home, 'backups'), { recursive: true });

  const initializedAt = new Date().toISOString();
  const created = [
    writeJsonIfMissing(path.join(home, 'config.json'), {
      schemaVersion: SCHEMA_VERSION,
      product: 'KaleidoSphere',
      initializedAt
    }),
    writeJsonIfMissing(path.join(registryPath, 'workspaces.json'), {
      schemaVersion: SCHEMA_VERSION,
      workspaces: []
    }),
    writeJsonIfMissing(path.join(registryPath, 'projects.json'), {
      schemaVersion: SCHEMA_VERSION,
      projects: []
    }),
    writeJsonIfMissing(path.join(registryPath, 'sparks.json'), {
      schemaVersion: SCHEMA_VERSION,
      sparks: []
    })
  ];

  return created.some(Boolean);
}

function printResult(result, json) {
  if (json) {
    process.stdout.write(`${JSON.stringify(result)}\n`);
    return;
  }

  if (Object.hasOwn(result, 'initialized')) {
    const action = result.initialized ? 'initialized' : 'already initialized';
    process.stdout.write(`KaleidoSphere registry ${action}: ${result.home}\n`);
    return;
  }

  if (result.workspace) {
    process.stdout.write(`Workspace registered: ${result.workspace.id} -> ${result.workspace.path}\n`);
  }
}

function addWorkspace(home, args) {
  const registryFile = path.join(home, 'registry', 'workspaces.json');
  if (!fs.existsSync(registryFile)) {
    throw new Error('registry is not initialized; run ks init first');
  }

  const id = option(args, '--id', true);
  const workspacePath = path.resolve(option(args, '--path', true));
  const mode = option(args, '--mode') || 'managed';
  if (mode !== 'managed') {
    throw new Error(`unsupported workspace mode: ${mode}`);
  }

  const registry = readJson(registryFile);
  if (registry.workspaces.some((workspace) => workspace.id === id)) {
    throw new Error(`workspace id already exists: ${id}`);
  }

  fs.mkdirSync(workspacePath, { recursive: true });
  const workspace = { id, path: workspacePath, mode };
  registry.workspaces.push(workspace);
  writeJson(registryFile, registry);
  return workspace;
}

function listWorkspaces(home) {
  const registryFile = path.join(home, 'registry', 'workspaces.json');
  if (!fs.existsSync(registryFile)) {
    throw new Error('registry is not initialized; run ks init first');
  }
  return readJson(registryFile).workspaces;
}

function runGit(cwd, args) {
  const result = spawnSync('git', args, { cwd, encoding: 'utf8' });
  if (result.status !== 0) {
    throw new Error(`git ${args.join(' ')} failed: ${(result.stderr || result.stdout).trim()}`);
  }
  return result.stdout.trim();
}

function readGitIdentity(args) {
  const name = option(args, '--git-name');
  const email = option(args, '--git-email');
  if (Boolean(name) !== Boolean(email)) {
    throw new Error('--git-name and --git-email must be provided together');
  }
  return name ? { name, email } : null;
}

function configureGitIdentity(cwd, identity) {
  const commitIdentity = identity || LOCAL_GIT_COMMIT_IDENTITY;
  runGit(cwd, ['config', 'user.name', commitIdentity.name]);
  runGit(cwd, ['config', 'user.email', commitIdentity.email]);
}

function createProject(home, args) {
  const workspacesFile = path.join(home, 'registry', 'workspaces.json');
  const projectsFile = path.join(home, 'registry', 'projects.json');
  if (!fs.existsSync(workspacesFile) || !fs.existsSync(projectsFile)) {
    throw new Error('registry is not initialized; run ks init first');
  }

  const workspaceId = option(args, '--workspace', true);
  const name = option(args, '--name', true);
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(name)) {
    throw new Error('--name must use lowercase kebab-case');
  }

  const workspaces = readJson(workspacesFile).workspaces;
  const workspace = workspaces.find((item) => item.id === workspaceId);
  if (!workspace) {
    throw new Error(`workspace does not exist: ${workspaceId}`);
  }

  const projects = readJson(projectsFile);
  if (projects.projects.some((project) => project.name === name && project.workspace === workspaceId)) {
    throw new Error(`project already exists in workspace: ${name}`);
  }

  const projectPath = path.join(workspace.path, name);
  if (fs.existsSync(projectPath)) {
    throw new Error(`project path already exists: ${projectPath}`);
  }

  const gitIdentity = readGitIdentity(args);
  const createdAt = new Date().toISOString();
  const project = {
    id: `prj_${randomUUID()}`,
    name,
    workspace: workspaceId,
    path: projectPath,
    layout: 'envelope',
    createdAt,
    updatedAt: createdAt
  };
  const repoPath = path.join(projectPath, 'repo');
  const contextPath = path.join(projectPath, 'ks-context');

  fs.mkdirSync(repoPath, { recursive: true });
  fs.mkdirSync(contextPath, { recursive: true });
  fs.writeFileSync(path.join(repoPath, 'README.md'), `# ${name}\n`);
  fs.writeFileSync(path.join(projectPath, '.gitignore'), 'repo/\n');
  fs.writeFileSync(path.join(projectPath, 'README.md'), `# ${name}\n\nLocal development workspace managed by KaleidoSphere.\n`);
  writeJson(path.join(contextPath, 'project.json'), {
    schemaVersion: SCHEMA_VERSION,
    id: project.id,
    name: project.name,
    workspace: project.workspace,
    createdAt: project.createdAt,
    gitIdentity
  });

  runGit(repoPath, ['init']);
  configureGitIdentity(repoPath, gitIdentity);
  runGit(repoPath, ['add', 'README.md']);
  runGit(repoPath, ['commit', '-m', `chore: initialize ${name} project repository`]);
  runGit(projectPath, ['init']);
  configureGitIdentity(projectPath, gitIdentity);
  runGit(projectPath, ['add', '.gitignore', 'README.md', 'ks-context']);
  runGit(projectPath, ['commit', '-m', `chore: initialize ${name} development workspace`]);

  projects.projects.push(project);
  writeJson(projectsFile, projects);
  return project;
}

function registerProject(home, args) {
  const workspaceId = option(args, '--workspace', true);
  const name = option(args, '--name', true);
  const projectPath = path.resolve(option(args, '--path', true));
  const layout = option(args, '--layout') || 'direct';
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(name)) {
    throw new Error('--name must use lowercase kebab-case');
  }
  if (layout !== 'direct') {
    throw new Error('project register currently supports only --layout direct');
  }
  const workspaces = listWorkspaces(home);
  const workspace = workspaces.find((item) => item.id === workspaceId);
  if (!workspace) throw new Error(`workspace does not exist: ${workspaceId}`);
  if (!projectPath.startsWith(`${workspace.path}${path.sep}`)) {
    throw new Error('project path must be inside the registered workspace');
  }
  if (!fs.existsSync(path.join(projectPath, '.git'))) {
    throw new Error('project register requires an existing Git repository');
  }
  const projectsFile = path.join(home, 'registry', 'projects.json');
  if (!fs.existsSync(projectsFile)) {
    throw new Error('registry is not initialized; run ks init first');
  }
  const projects = readJson(projectsFile);
  if (projects.projects.some((project) => project.path === projectPath || (project.name === name && project.workspace === workspaceId))) {
    throw new Error(`project is already registered: ${projectPath}`);
  }
  const now = new Date().toISOString();
  const project = { id: `prj_${randomUUID()}`, name, workspace: workspaceId, path: projectPath, layout, createdAt: now, updatedAt: now };
  projects.projects.push(project);
  writeJson(projectsFile, projects);
  return project;
}

function listProjects(home) {
  const registryFile = path.join(home, 'registry', 'projects.json');
  if (!fs.existsSync(registryFile)) {
    throw new Error('registry is not initialized; run ks init first');
  }
  return readJson(registryFile).projects;
}

function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  if (command === '--version' || command === '-v') {
    process.stdout.write(`${PACKAGE_VERSION}\n`);
    return;
  }
  const json = args.includes('--json');

  const home = resolveKsHome(args);
  if (command === 'init') {
    printResult({ ok: true, initialized: initialize(home), home }, json);
    return;
  }

  if (command === 'workspace' && args[1] === 'add') {
    printResult({ ok: true, workspace: addWorkspace(home, args) }, json);
    return;
  }

  if (command === 'workspace' && args[1] === 'list') {
    printResult({ ok: true, workspaces: listWorkspaces(home) }, true);
    return;
  }

  if (command === 'project' && args[1] === 'create') {
    printResult({ ok: true, project: createProject(home, args) }, json);
    return;
  }

  if (command === 'project' && args[1] === 'register') {
    printResult({ ok: true, project: registerProject(home, args) }, json);
    return;
  }

  if (command === 'project' && args[1] === 'list') {
    printResult({ ok: true, projects: listProjects(home) }, true);
    return;
  }

  throw new Error('Usage: ks init | ks workspace <add|list> | ks project <create|register|list> [--home <path>] [--json]');
}

try {
  main();
} catch (error) {
  process.stderr.write(`ks: ${error.message}\n`);
  process.exitCode = 1;
}
