#!/usr/bin/env node

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { randomUUID, createHash } = require('node:crypto');
const { spawnSync } = require('node:child_process');

const SCHEMA_VERSION = 1;
const PACKAGE_VERSION = require('../package.json').version;
const LOCAL_GIT_COMMIT_IDENTITY = {
  name: 'KaleidoSphere Local',
  email: 'local@kaleidosphere.invalid'
};

function resolveKsHome(args) {
  const homeIndex = args.indexOf('--home');
  if (homeIndex !== -1) {
    const configuredHome = args[homeIndex + 1];
    if (!configuredHome || configuredHome.startsWith('--')) {
      throw new Error('--home requires a directory path');
    }
    return path.resolve(configuredHome);
  }

  return path.resolve(process.env.KS_HOME || path.join(os.homedir(), '.ks'));
}

function writeJsonIfMissing(filePath, value) {
  if (fs.existsSync(filePath)) {
    return false;
  }

  const temporaryPath = `${filePath}.${process.pid}.${Date.now()}.tmp`;
  try {
    fs.writeFileSync(temporaryPath, `${JSON.stringify(value, null, 2)}\n`, { flag: 'wx' });
    fs.renameSync(temporaryPath, filePath);
    return true;
  } catch (error) {
    fs.rmSync(temporaryPath, { force: true });
    if (error.code === 'EEXIST' && fs.existsSync(filePath)) {
      return false;
    }
    throw error;
  }
}

function writeJson(filePath, value) {
  const temporaryPath = `${filePath}.${process.pid}.${Date.now()}.tmp`;
  try {
    fs.writeFileSync(temporaryPath, `${JSON.stringify(value, null, 2)}\n`, { flag: 'wx' });
    fs.renameSync(temporaryPath, filePath);
  } catch (error) {
    fs.rmSync(temporaryPath, { force: true });
    throw error;
  }
}

function withRegistryLock(home, callback) {
  const lockPath = path.join(home, 'state', 'registry.lock');
  fs.mkdirSync(path.dirname(lockPath), { recursive: true });
  let descriptor;
  try {
    descriptor = fs.openSync(lockPath, 'wx');
  } catch (error) {
    if (error.code === 'EEXIST') {
      throw new Error('registry is busy; retry after the active KS operation finishes');
    }
    throw error;
  }
  try {
    return callback();
  } finally {
    fs.closeSync(descriptor);
    fs.rmSync(lockPath, { force: true });
  }
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function option(args, name, required = false) {
  const index = args.indexOf(name);
  const value = index === -1 ? undefined : args[index + 1];
  if (required && (!value || value.startsWith('--'))) {
    throw new Error(`${name} requires a value`);
  }
  return value;
}

function initialize(home) {
  const registryPath = path.join(home, 'registry');
  fs.mkdirSync(registryPath, { recursive: true });
  fs.mkdirSync(path.join(home, 'state'), { recursive: true });
  fs.mkdirSync(path.join(home, 'backups'), { recursive: true });

  const initializedAt = new Date().toISOString();
  const created = [
    writeJsonIfMissing(path.join(home, 'config.json'), {
      schemaVersion: SCHEMA_VERSION,
      product: 'KaleidoSphere',
      initializedAt
    }),
    writeJsonIfMissing(path.join(registryPath, 'workspaces.json'), {
      schemaVersion: SCHEMA_VERSION,
      workspaces: []
    }),
    writeJsonIfMissing(path.join(registryPath, 'projects.json'), {
      schemaVersion: SCHEMA_VERSION,
      projects: []
    }),
    writeJsonIfMissing(path.join(registryPath, 'sparks.json'), {
      schemaVersion: SCHEMA_VERSION,
      sparks: []
    })
  ];

  return created.some(Boolean);
}

function printResult(result, json) {
  if (json) {
    process.stdout.write(`${JSON.stringify(result)}\n`);
    return;
  }

  if (Object.hasOwn(result, 'initialized')) {
    const action = result.initialized ? 'initialized' : 'already initialized';
    process.stdout.write(`KaleidoSphere registry ${action}: ${result.home}\n`);
    return;
  }

  if (result.workspace) {
    process.stdout.write(`Workspace registered: ${result.workspace.id} -> ${result.workspace.path}\n`);
  }
}

function addWorkspace(home, args) {
  const registryFile = path.join(home, 'registry', 'workspaces.json');
  if (!fs.existsSync(registryFile)) {
    throw new Error('registry is not initialized; run ks init first');
  }

  const id = option(args, '--id', true);
  const workspacePath = path.resolve(option(args, '--path', true));
  const mode = option(args, '--mode') || 'managed';
  if (mode !== 'managed') {
    throw new Error(`unsupported workspace mode: ${mode}`);
  }

  const registry = readJson(registryFile);
  if (registry.workspaces.some((workspace) => workspace.id === id)) {
    throw new Error(`workspace id already exists: ${id}`);
  }

  fs.mkdirSync(workspacePath, { recursive: true });
  const workspace = { id, path: workspacePath, mode };
  registry.workspaces.push(workspace);
  writeJson(registryFile, registry);
  return workspace;
}

function listWorkspaces(home) {
  const registryFile = path.join(home, 'registry', 'workspaces.json');
  if (!fs.existsSync(registryFile)) {
    throw new Error('registry is not initialized; run ks init first');
  }
  return readJson(registryFile).workspaces;
}

function runGit(cwd, args) {
  const result = spawnSync('git', args, { cwd, encoding: 'utf8' });
  if (result.status !== 0) {
    throw new Error(`git ${args.join(' ')} failed: ${(result.stderr || result.stdout).trim()}`);
  }
  return result.stdout.trim();
}

function tryGit(cwd, args) {
  const result = spawnSync('git', args, { cwd, encoding: 'utf8' });
  return result.status === 0 ? result.stdout.trim() : null;
}

function readGitIdentity(args) {
  const name = option(args, '--git-name');
  const email = option(args, '--git-email');
  if (Boolean(name) !== Boolean(email)) {
    throw new Error('--git-name and --git-email must be provided together');
  }
  return name ? { name, email } : null;
}

function configureGitIdentity(cwd, identity) {
  const commitIdentity = identity || LOCAL_GIT_COMMIT_IDENTITY;
  runGit(cwd, ['config', 'user.name', commitIdentity.name]);
  runGit(cwd, ['config', 'user.email', commitIdentity.email]);
}

function isPathInside(parentPath, candidatePath) {
  const relative = path.relative(parentPath, candidatePath);
  return relative && !relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative);
}

function readProjects(home) {
  const projectsFile = path.join(home, 'registry', 'projects.json');
  if (!fs.existsSync(projectsFile)) {
    throw new Error('registry is not initialized; run ks init first');
  }
  return { file: projectsFile, registry: readJson(projectsFile) };
}

function requireProject(home, projectId) {
  const projects = readProjects(home);
  const project = projects.registry.projects.find((item) => item.id === projectId);
  if (!project) {
    throw new Error(`project does not exist: ${projectId}`);
  }
  const workspace = listWorkspaces(home).find((item) => item.id === project.workspace);
  if (!workspace) {
    throw new Error(`registered workspace does not exist: ${project.workspace}`);
  }
  if (!isPathInside(workspace.path, project.path)) {
    throw new Error('registered project path is outside its workspace');
  }
  return { ...projects, project, workspace };
}

function gitStatus(cwd) {
  return runGit(cwd, ['status', '--porcelain=v1', '--untracked-files=all']);
}

function trackedFiles(cwd, directory) {
  const output = runGit(cwd, ['ls-files', '--', directory]);
  return output ? output.split('\n') : [];
}

function writeProjectDescriptor(contextPath, project, gitIdentity = null) {
  const descriptorPath = path.join(contextPath, 'project.json');
  if (fs.existsSync(descriptorPath)) {
    const descriptor = readJson(descriptorPath);
    if (descriptor.id !== project.id || descriptor.name !== project.name || descriptor.workspace !== project.workspace) {
      throw new Error('ks-context/project.json does not match the registered project identity');
    }
    return;
  }
  writeJson(descriptorPath, {
    schemaVersion: SCHEMA_VERSION,
    id: project.id,
    name: project.name,
    workspace: project.workspace,
    createdAt: project.createdAt,
    gitIdentity
  });
}

function ensureRepoIgnored(projectPath) {
  const gitignorePath = path.join(projectPath, '.gitignore');
  const existing = fs.existsSync(gitignorePath) ? fs.readFileSync(gitignorePath, 'utf8') : '';
  const lines = existing.split(/\r?\n/).filter(Boolean);
  if (!lines.includes('repo/')) {
    lines.push('repo/');
    fs.writeFileSync(gitignorePath, `${lines.join('\n')}\n`);
  }
}

function createProject(home, args) {
  const workspacesFile = path.join(home, 'registry', 'workspaces.json');
  const projectsFile = path.join(home, 'registry', 'projects.json');
  if (!fs.existsSync(workspacesFile) || !fs.existsSync(projectsFile)) {
    throw new Error('registry is not initialized; run ks init first');
  }

  const workspaceId = option(args, '--workspace', true);
  const name = option(args, '--name', true);
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(name)) {
    throw new Error('--name must use lowercase kebab-case');
  }

  const workspaces = readJson(workspacesFile).workspaces;
  const workspace = workspaces.find((item) => item.id === workspaceId);
  if (!workspace) {
    throw new Error(`workspace does not exist: ${workspaceId}`);
  }

  const projects = readJson(projectsFile);
  if (projects.projects.some((project) => project.name === name && project.workspace === workspaceId)) {
    throw new Error(`project already exists in workspace: ${name}`);
  }

  const projectPath = path.join(workspace.path, name);
  if (fs.existsSync(projectPath)) {
    throw new Error(`project path already exists: ${projectPath}`);
  }

  const gitIdentity = readGitIdentity(args);
  const createdAt = new Date().toISOString();
  const project = {
    id: `prj_${randomUUID()}`,
    name,
    workspace: workspaceId,
    path: projectPath,
    layout: 'worksite',
    createdAt,
    updatedAt: createdAt
  };
  const repoPath = path.join(projectPath, 'repo');
  const contextPath = path.join(projectPath, 'ks-context');

  fs.mkdirSync(repoPath, { recursive: true });
  fs.mkdirSync(contextPath, { recursive: true });
  fs.writeFileSync(path.join(repoPath, 'README.md'), `# ${name}\n`);
  fs.writeFileSync(path.join(projectPath, '.gitignore'), 'repo/\n');
  fs.writeFileSync(path.join(projectPath, 'README.md'), `# ${name}\n\nLocal development workspace managed by KaleidoSphere.\n`);
  writeProjectDescriptor(contextPath, project, gitIdentity);

  runGit(repoPath, ['init']);
  configureGitIdentity(repoPath, gitIdentity);
  runGit(repoPath, ['add', 'README.md']);
  runGit(repoPath, ['commit', '-m', `chore: initialize ${name} project repository`]);
  runGit(projectPath, ['init']);
  configureGitIdentity(projectPath, gitIdentity);
  runGit(projectPath, ['add', '.gitignore', 'README.md', 'ks-context']);
  runGit(projectPath, ['commit', '-m', `chore: initialize ${name} development workspace`]);

  projects.projects.push(project);
  writeJson(projectsFile, projects);
  return project;
}

function registerProject(home, args) {
  const workspaceId = option(args, '--workspace', true);
  const name = option(args, '--name', true);
  const projectPath = path.resolve(option(args, '--path', true));
  const layout = option(args, '--layout') || 'direct';
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(name)) {
    throw new Error('--name must use lowercase kebab-case');
  }
  if (layout !== 'direct') {
    throw new Error('project register only records an existing direct repository; use project create for a new development worksite');
  }
  const workspaces = listWorkspaces(home);
  const workspace = workspaces.find((item) => item.id === workspaceId);
  if (!workspace) throw new Error(`workspace does not exist: ${workspaceId}`);
  if (!isPathInside(workspace.path, projectPath)) {
    throw new Error('project path must be inside the registered workspace');
  }
  if (!fs.existsSync(path.join(projectPath, '.git'))) {
    throw new Error('project register requires an existing Git repository');
  }
  const { file: projectsFile, registry: projects } = readProjects(home);
  if (projects.projects.some((project) => project.path === projectPath || (project.name === name && project.workspace === workspaceId))) {
    throw new Error(`project is already registered: ${projectPath}`);
  }
  const now = new Date().toISOString();
  const project = { id: `prj_${randomUUID()}`, name, workspace: workspaceId, path: projectPath, layout, createdAt: now, updatedAt: now };
  projects.projects.push(project);
  writeJson(projectsFile, projects);
  return project;
}

function listProjects(home) {
  const registryFile = path.join(home, 'registry', 'projects.json');
  if (!fs.existsSync(registryFile)) {
    throw new Error('registry is not initialized; run ks init first');
  }
  return readJson(registryFile).projects;
}

function updateProject(home, args) {
  const projectId = option(args, '--id', true);
  const name = option(args, '--name');
  const workspaceId = option(args, '--workspace');
  const requestedPath = option(args, '--path');
  const requestedLayout = option(args, '--layout');
  if (!name && !workspaceId && !requestedPath && !requestedLayout) {
    throw new Error('project update requires at least one of --name, --workspace, --path, or --layout');
  }
  if (name && !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(name)) {
    throw new Error('--name must use lowercase kebab-case');
  }

  const projectsFile = path.join(home, 'registry', 'projects.json');
  if (!fs.existsSync(projectsFile)) {
    throw new Error('registry is not initialized; run ks init first');
  }
  const projects = readJson(projectsFile);
  const project = projects.projects.find((item) => item.id === projectId);
  if (!project) {
    throw new Error(`project does not exist: ${projectId}`);
  }

  const targetWorkspaceId = workspaceId || project.workspace;
  const workspaces = listWorkspaces(home);
  const workspace = workspaces.find((item) => item.id === targetWorkspaceId);
  if (!workspace) {
    throw new Error(`workspace does not exist: ${targetWorkspaceId}`);
  }

  const targetPath = requestedPath ? path.resolve(requestedPath) : project.path;
  if (!isPathInside(workspace.path, targetPath)) {
    throw new Error('project path must be inside the registered workspace');
  }
  const targetLayout = requestedLayout || project.layout;
  if (!['direct', 'worksite'].includes(targetLayout)) {
    throw new Error('--layout must be direct or worksite');
  }
  const repositoryPath = targetLayout === 'worksite' ? path.join(targetPath, 'repo') : targetPath;
  if (!fs.existsSync(path.join(repositoryPath, '.git'))) {
    throw new Error('project update requires an existing Git repository at the selected layout');
  }
  if (targetLayout === 'worksite' && !fs.existsSync(path.join(targetPath, 'ks-context', 'project.json'))) {
    throw new Error('project update requires ks-context/project.json for layout worksite');
  }

  const targetName = name || project.name;
  if (projects.projects.some((item) => item.id !== projectId && (item.path === targetPath || (item.name === targetName && item.workspace === targetWorkspaceId)))) {
    throw new Error(`project registration conflicts with an existing project: ${targetPath}`);
  }

  project.name = targetName;
  project.workspace = targetWorkspaceId;
  project.path = targetPath;
  project.layout = targetLayout;
  project.updatedAt = new Date().toISOString();
  writeJson(projectsFile, projects);
  return project;
}

function inspectProject(home, args) {
  const { project, workspace } = requireProject(home, option(args, '--id', true));
  const repoPath = project.layout === 'worksite' ? path.join(project.path, 'repo') : project.path;
  return {
    project,
    workspace,
    repoPath,
    registeredPathExists: fs.existsSync(project.path),
    repositoryExists: fs.existsSync(path.join(repoPath, '.git'))
  };
}

function resolveProject(home, args) {
  const targetPath = path.resolve(option(args, '--path', true));
  const projects = listProjects(home);
  const project = projects.find((item) => {
    const repoPath = item.layout === 'worksite' ? path.join(item.path, 'repo') : item.path;
    return targetPath === item.path || targetPath === repoPath || isPathInside(item.path, targetPath);
  });
  if (!project) {
    throw new Error(`no registered project contains path: ${targetPath}`);
  }
  return inspectProject(home, ['--id', project.id]);
}

function checkProject(home, args) {
  const { project, workspace } = requireProject(home, option(args, '--id', true));
  const checks = [];
  const add = (id, passed, message, remediation) => checks.push({ id, passed, message, remediation: passed ? null : remediation });
  const projectPath = project.path;
  const repoPath = path.join(projectPath, 'repo');
  const contextPath = path.join(projectPath, 'ks-context');
  const outerGitPath = path.join(projectPath, '.git');

  add('layout.worksite', project.layout === 'worksite', project.layout === 'worksite' ? '登记布局为标准开发现场。' : `登记布局为 ${project.layout}，尚未迁入标准开发现场。`, '在用户明确确认后，先生成迁入计划，再按计划执行迁入。');
  add('path.exists', fs.existsSync(projectPath), fs.existsSync(projectPath) ? '登记项目路径存在。' : '登记项目路径不存在。', '确认项目是否被移动、删除或需要修正登记路径。');
  const hasOuterGit = project.layout === 'worksite' && fs.existsSync(outerGitPath);
  add('outer.git', hasOuterGit, hasOuterGit ? '开发现场外层 Git 存在。' : project.layout === 'direct' ? '当前 direct 根的 .git 属于项目本体，不是开发现场外层 Git。' : '开发现场外层 Git 不存在。', '通过受控修复流程初始化外层 Git；不要把 repo/.git 当作外层 Git。');
  add('repo.git', fs.existsSync(path.join(repoPath, '.git')), fs.existsSync(path.join(repoPath, '.git')) ? 'repo/ 中的项目本体 Git 存在。' : 'repo/ 中没有项目本体 Git。', '确认项目本体是否仍在 repo/，或在用户确认后执行迁入/登记修复。');
  add('context.exists', fs.existsSync(contextPath), fs.existsSync(contextPath) ? 'ks-context/ 存在。' : 'ks-context/ 不存在。', '通过受控修复流程创建 ks-context/；不要向 repo/ 写入 KS 专用上下文。');

  const descriptorPath = path.join(contextPath, 'project.json');
  let descriptor = null;
  let descriptorError = null;
  if (fs.existsSync(descriptorPath)) {
    try {
      descriptor = readJson(descriptorPath);
    } catch (error) {
      descriptorError = error.message;
    }
  }
  const descriptorMatches = descriptor && descriptor.id === project.id && descriptor.name === project.name && descriptor.workspace === project.workspace;
  add('context.identity', Boolean(descriptorMatches), descriptorMatches ? 'ks-context/project.json 与登记项目身份一致。' : descriptorError ? `ks-context/project.json 无法解析：${descriptorError}` : fs.existsSync(descriptorPath) ? 'ks-context/project.json 与登记项目身份不一致。' : 'ks-context/project.json 不存在。', '通过受控修复流程恢复与 registry 一致的 project.json，禁止直接改写 ~/.ks。');

  const ignoredRepo = project.layout === 'worksite' && fs.existsSync(path.join(projectPath, '.gitignore')) && fs.readFileSync(path.join(projectPath, '.gitignore'), 'utf8').split(/\r?\n/).includes('repo/');
  add('outer.ignore-repo', ignoredRepo, ignoredRepo ? '外层 .gitignore 已忽略 repo/。' : project.layout === 'direct' ? 'direct 项目尚无外层 .gitignore 的 repo/ 隔离规则。' : '外层 .gitignore 没有忽略 repo/。', '在外层 .gitignore 增加 repo/，避免项目本体进入开发现场 Git。');

  const outerTracked = hasOuterGit ? tryGit(projectPath, ['ls-files', '--', 'repo']) : null;
  const trackedRepoFiles = outerTracked ? outerTracked.split('\n').filter(Boolean) : [];
  add('outer.untracked-repo', hasOuterGit && trackedRepoFiles.length === 0, hasOuterGit && trackedRepoFiles.length === 0 ? '外层 Git 未追踪 repo/。' : project.layout === 'direct' ? 'direct 项目尚无可验证的外层 Git 隔离。' : `外层 Git 错误追踪了 repo/ 中的 ${trackedRepoFiles.length} 个文件。`, '停止向外层 Git 暂存 repo/，并在用户确认后通过 Git 正常移除错误追踪。');

  return {
    project,
    workspace,
    compliant: checks.every((check) => check.passed),
    checks,
    diagnostics: {
      outerGitStatus: hasOuterGit ? tryGit(projectPath, ['status', '--porcelain=v1', '--untracked-files=all']) : null,
      repoGitStatus: fs.existsSync(path.join(repoPath, '.git')) ? tryGit(repoPath, ['status', '--porcelain=v1', '--untracked-files=all']) : null,
      repositoryPath: repoPath
    }
  };
}

function migrationPlan(home, args) {
  const { project, workspace } = requireProject(home, option(args, '--id', true));
  const targetLayout = option(args, '--to-layout', true);
  if (targetLayout !== 'worksite') {
    throw new Error('project migration currently supports only --to-layout worksite');
  }
  if (project.layout !== 'direct') {
    throw new Error(`project migration requires layout direct; current layout is ${project.layout}`);
  }
  const projectPath = project.path;
  const repoPath = path.join(projectPath, 'repo');
  if (!isPathInside(workspace.path, projectPath) || !fs.existsSync(projectPath)) {
    throw new Error('registered direct project path is unavailable inside its workspace');
  }
  if (!fs.statSync(path.join(projectPath, '.git')).isDirectory()) {
    throw new Error('project migration requires a direct Git working tree with a .git directory');
  }
  if (fs.existsSync(repoPath)) {
    throw new Error(`project migration target already exists: ${repoPath}`);
  }

  const contextPath = path.join(projectPath, 'ks-context');
  const hasContext = fs.existsSync(contextPath);
  const extractContext = args.includes('--extract-context');
  const preserveWorktree = args.includes('--preserve-worktree');
  const status = gitStatus(projectPath);
  const trackedContext = hasContext ? trackedFiles(projectPath, 'ks-context') : [];
  const statusLines = status ? status.split('\n') : [];
  const nonContextChanges = statusLines.filter((line) => !line.slice(3).startsWith('ks-context/'));
  if (nonContextChanges.length > 0 && !preserveWorktree) {
    throw new Error(`source worktree has changes outside ks-context; rerun with --preserve-worktree to include them in an explicit migration plan: ${nonContextChanges.join(', ')}`);
  }
  if ((hasContext || trackedContext.length > 0) && !extractContext) {
    throw new Error('project migration found ks-context; rerun with --extract-context to move it outside the repository');
  }
  const descriptorPath = path.join(contextPath, 'project.json');
  if (fs.existsSync(descriptorPath)) {
    writeProjectDescriptor(contextPath, project);
  }
  const head = runGit(projectPath, ['rev-parse', 'HEAD']);
  const branch = runGit(projectPath, ['branch', '--show-current']);
  const remote = tryGit(projectPath, ['remote', 'get-url', 'origin']);
  const planId = createHash('sha256').update(JSON.stringify({ id: project.id, path: projectPath, head, branch, remote, status, extractContext, preserveWorktree })).digest('hex').slice(0, 16);
  return {
    planId,
    projectId: project.id,
    source: projectPath,
    target: { worksite: projectPath, repo: repoPath, context: path.join(projectPath, 'ks-context') },
    extraction: { required: hasContext || trackedContext.length > 0, trackedFiles: trackedContext, sourceStatus: statusLines },
    preserveWorktree,
    repository: { head, branch, remote: remote || null },
    nextLayout: 'worksite'
  };
}

function migrateProject(home, args) {
  const plan = migrationPlan(home, args);
  if (!args.includes('--apply')) return { applied: false, plan };
  const suppliedPlanId = option(args, '--plan', true);
  if (suppliedPlanId !== plan.planId) {
    throw new Error('migration plan has changed; rerun without --apply to review the current plan');
  }

  const { project } = requireProject(home, plan.projectId);
  const projectPath = project.path;
  const parentPath = path.dirname(projectPath);
  const temporaryPath = path.join(parentPath, `.${path.basename(projectPath)}.ks-migrate-${randomUUID()}`);
  const contextPath = path.join(projectPath, 'ks-context');
  const repoPath = path.join(projectPath, 'repo');
  let movedRoot = false;
  try {
    fs.renameSync(projectPath, temporaryPath);
    movedRoot = true;
    fs.mkdirSync(projectPath);
    if (fs.existsSync(path.join(temporaryPath, 'ks-context'))) {
      fs.renameSync(path.join(temporaryPath, 'ks-context'), contextPath);
    } else {
      fs.mkdirSync(contextPath, { recursive: true });
    }
    fs.mkdirSync(repoPath);
    for (const entry of fs.readdirSync(temporaryPath)) {
      fs.renameSync(path.join(temporaryPath, entry), path.join(repoPath, entry));
    }
    fs.rmdirSync(temporaryPath);
    ensureRepoIgnored(projectPath);
    writeProjectDescriptor(contextPath, project);
    runGit(projectPath, ['init']);
    configureGitIdentity(projectPath, null);
    runGit(projectPath, ['add', '.gitignore', 'ks-context']);
    runGit(projectPath, ['commit', '-m', `chore: initialize ${project.name} development workspace`]);
    const migratedProject = withRegistryLock(home, () => {
      const { registry, file: projectsFile } = readProjects(home);
      const current = registry.projects.find((item) => item.id === project.id);
      if (!current || current.layout !== 'direct' || current.path !== projectPath) {
        throw new Error('project registration changed during migration; registry was not updated');
      }
      current.layout = 'worksite';
      current.updatedAt = new Date().toISOString();
      writeJson(projectsFile, registry);
      return current;
    });
    return { applied: true, plan, project: migratedProject };
  } catch (error) {
    if (movedRoot) {
      try {
        fs.rmSync(projectPath, { recursive: true, force: true });
        fs.renameSync(temporaryPath, projectPath);
      } catch (rollbackError) {
        throw new Error(`${error.message}; automatic rollback failed: ${rollbackError.message}`);
      }
    }
    throw error;
  }
}

function projectRepositoryPath(project) {
  return project.layout === 'worksite' ? path.join(project.path, 'repo') : project.path;
}

function requireWorksiteProject(home, args) {
  const result = requireProject(home, option(args, '--id', true));
  if (result.project.layout !== 'worksite') {
    throw new Error('this operation requires a project using the worksite layout');
  }
  return { ...result, repoPath: projectRepositoryPath(result.project), contextPath: path.join(result.project.path, 'ks-context') };
}

function planDirectory(home) {
  const directory = path.join(home, 'state', 'plans');
  fs.mkdirSync(directory, { recursive: true });
  return directory;
}

function savePlan(home, type, payload) {
  const plan = {
    id: `plan_${randomUUID()}`,
    type,
    createdAt: new Date().toISOString(),
    status: 'pending',
    ...payload
  };
  writeJson(path.join(planDirectory(home), `${plan.id}.json`), plan);
  return plan;
}

function loadPendingPlan(home, planId, expectedType) {
  const planPath = path.join(planDirectory(home), `${planId}.json`);
  if (!fs.existsSync(planPath)) throw new Error(`plan does not exist: ${planId}`);
  const plan = readJson(planPath);
  if (plan.type !== expectedType) throw new Error(`plan ${planId} is not a ${expectedType} plan`);
  if (plan.status !== 'pending') throw new Error(`plan is not pending: ${planId}`);
  return { plan, path: planPath };
}

function loadPendingPlanAny(home, planId) {
  const planPath = path.join(planDirectory(home), `${planId}.json`);
  if (!fs.existsSync(planPath)) throw new Error(`plan does not exist: ${planId}`);
  const plan = readJson(planPath);
  if (plan.status !== 'pending') throw new Error(`plan is not pending: ${planId}`);
  return { plan, path: planPath };
}

function completePlan(planPath, plan) {
  plan.status = 'applied';
  plan.appliedAt = new Date().toISOString();
  writeJson(planPath, plan);
}

function versioningPath(project) {
  return path.join(project.path, 'ks-context', 'versioning.yaml');
}

function projectRulesPath(project) {
  return path.join(project.path, 'ks-context', 'project-rules.md');
}

function agentRuleFiles(repoPath) {
  return ['AGENTS.md', 'CLAUDE.md', 'GEMINI.md']
    .map((name) => path.join(repoPath, name))
    .filter((filePath) => fs.existsSync(filePath));
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function upsertAtomicBlock(filePath, name, content) {
  const start = `<!-- ks:${name}:start -->`;
  const end = `<!-- ks:${name}:end -->`;
  const block = `${start}\n${content}\n${end}`;
  const existing = fs.readFileSync(filePath, 'utf8');
  const expression = new RegExp(`${escapeRegExp(start)}[\\s\\S]*?${escapeRegExp(end)}`, 'm');
  fs.writeFileSync(filePath, expression.test(existing) ? existing.replace(expression, block) : `${existing.replace(/\s*$/, '')}\n\n${block}\n`);
}

function removeAtomicBlock(filePath, name) {
  const start = `<!-- ks:${name}:start -->`;
  const end = `<!-- ks:${name}:end -->`;
  const existing = fs.readFileSync(filePath, 'utf8');
  const expression = new RegExp(`\\n?${escapeRegExp(start)}[\\s\\S]*?${escapeRegExp(end)}\\n?`, 'm');
  if (expression.test(existing)) fs.writeFileSync(filePath, existing.replace(expression, '\n'));
}

function readVersioning(project) {
  const filePath = versioningPath(project);
  if (!fs.existsSync(filePath)) return null;
  try {
    return { filePath, config: readJson(filePath) };
  } catch (error) {
    return { filePath, error: error.message };
  }
}

function versionStatus(home, args) {
  const { project, repoPath } = requireWorksiteProject(home, args);
  const versioning = readVersioning(project);
  const agentFiles = agentRuleFiles(repoPath);
  const enabled = project.versioning?.enabled;
  let state = 'needs_user_decision';
  if (versioning?.config?.enabled === true) state = 'managed';
  if (!versioning && enabled === false) state = 'unmanaged';
  if (versioning?.error) state = 'invalid';
  return {
    project,
    state,
    versioningFile: versioningPath(project),
    config: versioning?.config || null,
    error: versioning?.error || null,
    agentRuleFiles: agentFiles,
    message: state === 'needs_user_decision'
      ? '项目尚未声明 KS 版本管理策略；请询问用户，优先推荐统一版本。'
      : state === 'unmanaged'
        ? '项目已声明不由 KS 管理版本。'
        : state === 'managed'
          ? '项目由 KS 管理版本。'
          : '版本规则文件无效。'
  };
}

function parseComponents(args, mode, requiredVersion) {
  const entries = args.filter((value, index) => args[index - 1] === '--component');
  if (mode === 'unified') return [{ id: 'project', version: requiredVersion, targets: [] }];
  if (entries.length === 0) throw new Error('--mode independent requires one or more --component <name=version> values');
  return entries.map((entry) => {
    const [id, version] = entry.split('=');
    if (!id || !version) throw new Error('--component must use name=version');
    return { id, version, targets: [] };
  });
}

function versionInitPlan(home, args) {
  const { project, repoPath } = requireWorksiteProject(home, args);
  if (fs.existsSync(versioningPath(project))) throw new Error('versioning is already configured; use ks version plan to change an existing configuration');
  const mode = option(args, '--mode') || 'unified';
  if (!['unified', 'independent'].includes(mode)) throw new Error('--mode must be unified or independent');
  const version = option(args, '--version', true);
  const config = {
    schemaVersion: 1,
    enabled: true,
    mode,
    components: parseComponents(args, mode, version),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  return savePlan(home, 'version-init', {
    projectId: project.id,
    config,
    versioningFile: versioningPath(project),
    agentRuleFiles: agentRuleFiles(repoPath)
  });
}

function versionChangePlan(home, args) {
  const { project, repoPath } = requireWorksiteProject(home, args);
  if (args.includes('--disable')) {
    return savePlan(home, 'version-disable', {
      projectId: project.id,
      versioningFile: versioningPath(project),
      agentRuleFiles: agentRuleFiles(repoPath)
    });
  }
  const existing = readVersioning(project);
  if (!existing?.config) throw new Error('versioning is not configured; use ks version init first');
  const componentId = option(args, '--component', true);
  const nextVersion = option(args, '--set', true);
  const components = existing.config.components.map((component) => component.id === componentId ? { ...component, version: nextVersion } : component);
  if (!existing.config.components.some((component) => component.id === componentId)) throw new Error(`version component does not exist: ${componentId}`);
  return savePlan(home, 'version-change', {
    projectId: project.id,
    config: { ...existing.config, components, updatedAt: new Date().toISOString() },
    versioningFile: versioningPath(project),
    agentRuleFiles: agentRuleFiles(repoPath)
  });
}

function applyVersionPlan(home, args) {
  const planId = option(args, '--plan', true);
  const { plan, path: planPath } = loadPendingPlanAny(home, planId);
  if (!['version-init', 'version-change', 'version-disable'].includes(plan.type)) throw new Error(`plan ${planId} is not a version plan`);
  if (!args.includes('--apply')) return { applied: false, plan };
  const { project, repoPath } = requireWorksiteProject(home, ['--id', plan.projectId]);
  if (plan.versioningFile !== versioningPath(project)) throw new Error('project path changed; create a new version plan');
  if (plan.type === 'version-disable') {
    fs.rmSync(plan.versioningFile, { force: true });
    for (const agentFile of agentRuleFiles(repoPath)) removeAtomicBlock(agentFile, 'versioning');
  } else {
    fs.mkdirSync(path.dirname(plan.versioningFile), { recursive: true });
    writeJson(plan.versioningFile, plan.config);
    for (const agentFile of agentRuleFiles(repoPath)) {
      upsertAtomicBlock(agentFile, 'versioning', 'This project uses KS version management. Read `../ks-context/versioning.yaml` before changing versions or release metadata.');
    }
  }
  withRegistryLock(home, () => {
    const { file, registry } = readProjects(home);
    const current = registry.projects.find((item) => item.id === project.id);
    current.versioning = plan.type === 'version-disable'
      ? { enabled: false, updatedAt: new Date().toISOString() }
      : { enabled: true, file: 'ks-context/versioning.yaml', updatedAt: new Date().toISOString() };
    current.updatedAt = new Date().toISOString();
    writeJson(file, registry);
  });
  completePlan(planPath, plan);
  return { applied: true, plan, status: versionStatus(home, ['--id', project.id]) };
}

function versionCheck(home, args) {
  const status = versionStatus(home, args);
  const checks = [];
  const add = (id, passed, message) => checks.push({ id, passed, message });
  add('state.declared', ['managed', 'unmanaged'].includes(status.state), status.message);
  if (status.state === 'managed') {
    add('config.components', Array.isArray(status.config.components) && status.config.components.length > 0, '版本规则至少需要一个构件。');
    add('config.mode', ['unified', 'independent'].includes(status.config.mode), '版本规则模式必须是 unified 或 independent。');
    const agentReferences = status.agentRuleFiles.map((filePath) => fs.readFileSync(filePath, 'utf8').includes('<!-- ks:versioning:start -->'));
    add('agent.references', agentReferences.every(Boolean), status.agentRuleFiles.length === 0 ? '没有可注入的现有 Agent 规则文件。' : '现有 Agent 规则文件必须包含版本规则入口。');
  }
  return { ...status, compliant: checks.every((check) => check.passed), checks };
}

function projectRulesStatus(home, args) {
  const { project, repoPath } = requireWorksiteProject(home, args);
  const filePath = projectRulesPath(project);
  const content = fs.existsSync(filePath) ? fs.readFileSync(filePath, 'utf8') : null;
  const ruleIds = content ? [...content.matchAll(/^## Rule: (.+)$/gm)].map((match) => match[1]) : [];
  return { project, rulesFile: filePath, exists: Boolean(content), ruleIds, agentRuleFiles: agentRuleFiles(repoPath) };
}

function projectRulesPropose(home, args, action = 'add') {
  const { project, repoPath } = requireWorksiteProject(home, args);
  const ruleId = option(args, '--rule', true);
  const title = option(args, '--title') || ruleId;
  const text = action === 'add' ? option(args, '--text', true) : null;
  const current = projectRulesStatus(home, ['--id', project.id]);
  if (action === 'add' && current.ruleIds.includes(ruleId)) throw new Error(`project rule already exists: ${ruleId}`);
  if (action === 'remove' && !current.ruleIds.includes(ruleId)) throw new Error(`project rule does not exist: ${ruleId}`);
  return savePlan(home, `project-rules-${action}`, {
    projectId: project.id,
    rule: { id: ruleId, title, text },
    rulesFile: projectRulesPath(project),
    agentRuleFiles: agentRuleFiles(repoPath)
  });
}

function applyProjectRulesPlan(home, args) {
  const planId = option(args, '--plan', true);
  const planInfo = loadPendingPlanAny(home, planId);
  const { plan, path: planPath } = planInfo;
  if (!['project-rules-add', 'project-rules-remove'].includes(plan.type)) throw new Error(`plan ${planId} is not a project rules plan`);
  if (!args.includes('--apply')) return { applied: false, plan };
  const { project, repoPath } = requireWorksiteProject(home, ['--id', plan.projectId]);
  const rulesPath = projectRulesPath(project);
  let content = fs.existsSync(rulesPath) ? fs.readFileSync(rulesPath, 'utf8') : '# Project Development Rules\n';
  const expression = new RegExp(`\\n?## Rule: ${escapeRegExp(plan.rule.id)}\\n[\\s\\S]*?(?=\\n## Rule: |$)`, 'm');
  if (plan.type === 'project-rules-add') content = `${content.replace(/\s*$/, '')}\n\n## Rule: ${plan.rule.id}\n\n${plan.rule.text}\n`;
  else content = content.replace(expression, '\n').replace(/\n{3,}/g, '\n\n');
  fs.mkdirSync(path.dirname(rulesPath), { recursive: true });
  fs.writeFileSync(rulesPath, content);
  const agentFiles = agentRuleFiles(repoPath);
  if (plan.type === 'project-rules-add' || projectRulesStatus(home, ['--id', project.id]).ruleIds.length > 0) {
    for (const agentFile of agentFiles) upsertAtomicBlock(agentFile, 'project-rules', 'This project has persistent development rules. Read `../ks-context/project-rules.md` before making project changes.');
  } else {
    for (const agentFile of agentFiles) removeAtomicBlock(agentFile, 'project-rules');
  }
  completePlan(planPath, plan);
  return { applied: true, plan, status: projectRulesStatus(home, ['--id', project.id]) };
}

function projectRulesCheck(home, args) {
  const status = projectRulesStatus(home, args);
  const checks = [];
  const add = (id, passed, message) => checks.push({ id, passed, message });
  add('rules.file', status.exists, status.exists ? '项目元规则文件存在。' : '项目尚未沉淀元规则。');
  if (status.exists) {
    const agentReferences = status.agentRuleFiles.map((filePath) => fs.readFileSync(filePath, 'utf8').includes('<!-- ks:project-rules:start -->'));
    add('agent.references', agentReferences.every(Boolean), status.agentRuleFiles.length === 0 ? '没有可注入的现有 Agent 规则文件。' : '现有 Agent 规则文件必须包含元规则入口。');
  }
  return { ...status, compliant: checks.every((check) => check.passed), checks };
}

function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  if (command === '--version' || command === '-v') {
    process.stdout.write(`${PACKAGE_VERSION}\n`);
    return;
  }
  const json = args.includes('--json');

  const home = resolveKsHome(args);
  if (command === 'init') {
    printResult({ ok: true, initialized: initialize(home), home }, json);
    return;
  }

  if (command === 'workspace' && args[1] === 'add') {
    printResult({ ok: true, workspace: addWorkspace(home, args) }, json);
    return;
  }

  if (command === 'workspace' && args[1] === 'list') {
    printResult({ ok: true, workspaces: listWorkspaces(home) }, true);
    return;
  }

  if (command === 'project' && args[1] === 'create') {
    printResult({ ok: true, project: createProject(home, args) }, json);
    return;
  }

  if (command === 'project' && args[1] === 'register') {
    printResult({ ok: true, project: registerProject(home, args) }, json);
    return;
  }

  if (command === 'project' && args[1] === 'update') {
    printResult({ ok: true, project: updateProject(home, args) }, json);
    return;
  }

  if (command === 'project' && args[1] === 'list') {
    printResult({ ok: true, projects: listProjects(home) }, true);
    return;
  }

  if (command === 'project' && args[1] === 'inspect') {
    printResult({ ok: true, ...inspectProject(home, args) }, true);
    return;
  }

  if (command === 'project' && args[1] === 'resolve') {
    printResult({ ok: true, ...resolveProject(home, args) }, true);
    return;
  }

  if (command === 'project' && args[1] === 'check') {
    printResult({ ok: true, ...checkProject(home, args) }, true);
    return;
  }

  if (command === 'project' && args[1] === 'migrate') {
    printResult({ ok: true, ...migrateProject(home, args) }, true);
    return;
  }

  if (command === 'version' && args[1] === 'status') {
    printResult({ ok: true, ...versionStatus(home, args) }, true);
    return;
  }

  if (command === 'version' && args[1] === 'check') {
    printResult({ ok: true, ...versionCheck(home, args) }, true);
    return;
  }

  if (command === 'version' && args[1] === 'init') {
    if (args.includes('--apply')) throw new Error('version init creates a plan only; run ks version apply --plan <plan-id> --apply after review');
    printResult({ ok: true, applied: false, plan: versionInitPlan(home, args) }, true);
    return;
  }

  if (command === 'version' && args[1] === 'plan') {
    printResult({ ok: true, applied: false, plan: versionChangePlan(home, args) }, true);
    return;
  }

  if (command === 'version' && args[1] === 'apply') {
    printResult({ ok: true, ...applyVersionPlan(home, args) }, true);
    return;
  }

  if (command === 'project' && args[1] === 'rules' && args[2] === 'status') {
    printResult({ ok: true, ...projectRulesStatus(home, args) }, true);
    return;
  }

  if (command === 'project' && args[1] === 'rules' && args[2] === 'check') {
    printResult({ ok: true, ...projectRulesCheck(home, args) }, true);
    return;
  }

  if (command === 'project' && args[1] === 'rules' && args[2] === 'propose') {
    printResult({ ok: true, applied: false, plan: projectRulesPropose(home, args) }, true);
    return;
  }

  if (command === 'project' && args[1] === 'rules' && args[2] === 'remove') {
    printResult({ ok: true, applied: false, plan: projectRulesPropose(home, args, 'remove') }, true);
    return;
  }

  if (command === 'project' && args[1] === 'rules' && args[2] === 'apply') {
    printResult({ ok: true, ...applyProjectRulesPlan(home, args) }, true);
    return;
  }

  throw new Error('Usage: ks init | ks workspace <add|list> | ks project <create|register|update|list|inspect|resolve|check|migrate|rules> | ks version <status|init|check|plan|apply> [--home <path>] [--json]');
}

try {
  main();
} catch (error) {
  process.stderr.write(`ks: ${error.message}\n`);
  process.exitCode = 1;
}
