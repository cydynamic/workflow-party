# KFC Local Rules

KFC can install local routing rules for supported local agents. These rules switch the agent into KFC mode when the submitted prompt is concrete project work: development, testing, deployment, documentation, configuration, bugfix, review, acceptance, workflow state, or a deliverable. KFC mode means KFC is the workflow controller; it is not a checklist to run once before working. Generic requests such as spreadsheet checks, form checks, casual questions, or non-project review requests should not enter KFC.

## Supported Agents

- Codex: writes `<user-home>/.codex/hooks.json` with event lists under `hooks.UserPromptSubmit`, `hooks.PostToolUse`, and `hooks.Stop`.
- Claude Code: writes `<user-home>/.claude/settings.json` with `UserPromptSubmit`, `PostToolUse`, and `Stop` hook entries.
- Kiro: writes `<user-home>/.kiro/steering/kfc-routing.md`.

Agents that are not installed are skipped.

`<user-home>` is resolved with the local OS user home directory, so the same helper can run on macOS and Windows when Node.js is available to the current agent process.

## Event Roles

- `UserPromptSubmit`: classifies the request. For project work it enters KFC mode, invokes the installed `kfc` skill entrypoint with the original user request, reads the returned JSON, and then chooses route-only, execution with active session, execution needing continue, or blocked.
- `PostToolUse`: marks the active KFC workflow when an edit-like tool or write-like shell command changes code. Writes confined to `.kfc/` are workflow state or KFC artifacts and do not mark code changes; a mixed operation that also writes another project path still marks code changes.
- `Stop`: checks whether an active KFC step session or code-change quality gates are still pending. If an active step session exists, the agent must continue the same selected skill before the final response. If code changes left pending quality gates, the agent must continue KFC quality closeout before the final response.

Quality closeout uses the existing `test-and-selftest` stage: automated verification, runtime selftest, code review, security review, and review readiness packaging. These hooks must not create commits by themselves.

`PreToolUse` blocks AI-run commits by default. This protects formal and team projects where commit creation should stay with the user. For learning, practice, or personal projects, users may explicitly opt in through an agent rule file such as `AGENTS.md`, `CLAUDE.md`, `.claude/CLAUDE.md`, or `.codex/AGENTS.md`.

Recommended opt-in line:

```text
允许 AI 自动提交：是（仅限本练习/个人项目）
```

Machine-readable opt-in marker:

```text
KFC_ALLOW_AI_GIT_COMMIT=true
```

If KFC quality closeout is still pending, the commit remains blocked even when the project has opted in.

When a user explicitly says a quality gate is not applicable, a manual verification passed, or the current workflow should close, the agent must not treat the statement as an unrecorded bypass. It first records the instruction and its reason through the KFC router, then follows the returned state. `manual-pass` and `skip-gate` are limited to the current code-change generation; a later code change restores the normal quality gates. A recorded `close-workflow` ends the active step session and lets Stop/closeout release the closed workflow.

When KFC returns `active_step_session.status=in_progress`, local rules and Kiro steering tell the agent to stay in that session. The agent should not re-route, skip to another step, or call `complete` until the selected skill decides a recordable output is ready.

After every KFC command, the agent must inspect KFC fields such as `current_stage`, `stage_substep_context`, `active_step_session`, `next_required_action`, `next_step`, `selected_skill`, `flow_node_check`, `workflow_selection_required`, and `stage_update_applied`. Running KFC without consuming those fields does not satisfy KFC mode.

The local rule must treat `/kfc` as the KFC skill entrypoint. `/kfc` is not a shell command, MCP tool, project-local script, global PATH command, or direct route tool. `route --material` is an internal action performed by the KFC skill after the skill is entered; agents must not replace `/kfc` with MCP router calls or project command lookup.

KFC mode distinguishes:

- `route_only`: read-only project inspection, orientation, inventory, or explanation. The agent may answer from KFC context and inspected materials, but must not modify files, run tests, call `complete`, or claim the workflow advanced.
- `execution_with_active_session`: KFC already has an active selected skill session; the agent continues that skill.
- `execution_needs_continue`: the task may modify files, generate artifacts, run tests, review code, prepare deployment, fix bugs, implement requirements, or advance a deliverable. The agent aligns stage when needed, runs `continue`, uses the selected skill, then records output with `complete`.
- `blocked`: workflow selection, stage mismatch, missing material, or user confirmation must be resolved before work.

## Commands

Check hook status:

```bash
node kfc-flow-router/scripts/kfc.js hooks-check --root <workflow-root>
```

Install a missing rule:

```bash
node kfc-flow-router/scripts/kfc.js hooks-install --root <workflow-root> --agent codex
node kfc-flow-router/scripts/kfc.js hooks-install --root <workflow-root> --agent claude-code
node kfc-flow-router/scripts/kfc.js hooks-install --root <workflow-root> --agent kiro
```

Remove a KFC rule:

```bash
node kfc-flow-router/scripts/kfc.js hooks-remove --root <workflow-root> --agent codex
node kfc-flow-router/scripts/kfc.js hooks-remove --root <workflow-root> --agent claude-code
node kfc-flow-router/scripts/kfc.js hooks-remove --root <workflow-root> --agent kiro
```

`hooks-check` is read-only. `hooks-install` writes hook configuration or Kiro global steering and creates a timestamped backup when it modifies an existing file. `hooks-remove` only removes hook entries or steering files containing the KFC marker and also creates a timestamped backup before modifying or deleting a file. Codex hooks still need to be reviewed and trusted in `/hooks` after installation or update. When using the app, restart the app and open a new conversation if the authorization entry is not visible; the entry usually appears above the prompt box.

## Runtime Rule

KFC uses an explicit local-rule switch. Normal `/kfc ...` usage does not run local-rule guidance. AI should run rule status, enable, or disable only when the user explicitly enters one of these commands:

```text
/kfc hooks
/kfc hooks on
/kfc hooks off
```

`/kfc hooks` checks status only. `/kfc hooks on` enables KFC local routing rules for installed agents and skips agents that are not installed. For Kiro this creates the global steering file. `/kfc hooks off` removes only KFC-owned rules.

If an installed agent is missing a KFC rule during the status flow, AI should explain the user-facing effect first. If the user chooses to enable rules, run the on flow. If the user chooses to disable rules, run the off flow.

Codex hook entries are not active until the user trusts them in `/hooks`.
