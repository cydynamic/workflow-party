const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const test = require('node:test');
const root = path.resolve(__dirname, '..');
const cli = path.join(root, 'kfc/scripts/kfc.js');

test('个人运行时不继承公司注册表，空安装环境可使用包内默认 worker', (t) => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'kfc-personal-runtime-'));
  t.after(() => fs.rmSync(temp, { recursive: true, force: true }));
  const home = path.join(temp, 'home');
  fs.mkdirSync(path.join(home, '.local/legacy-kfc'), { recursive: true });
  fs.writeFileSync(path.join(home, '.local/legacy-kfc/skill-registry.json'), JSON.stringify({
    entries: [{ stage: 'requirement', step_id: 'requirement_discussion', skill: 'legacy-company-worker' }],
  }));
  const config = path.join(temp, 'personal-config');
  const run = (args) => JSON.parse(execFileSync(process.execPath, [cli, ...args], {
    env: { ...process.env, HOME: home, KFC_CONFIG_HOME: config }, encoding: 'utf8', timeout: 10000,
  }));
  const catalog = run(['catalog', '--stage', 'requirement']);
  assert(!catalog.available_skills.some((s) => s.name === 'legacy-company-worker'));
  const workflow = path.join(temp, 'project');
  run(['init', '--root', workflow, '--workflow-id', 'personal', '--stage', 'requirement']);
  const continued = run(['continue', '--root', workflow, '--workflow-id', 'personal']);
  assert.equal(continued.ok, true);
  assert.equal(continued.next_step.step_id, 'requirement_discussion');
  assert.equal(continued.dependency_check.install_attempted, false);
  assert(continued.registry_path === undefined || continued.registry_path.startsWith(config));
  const dependencies = run(['dependencies']);
  assert.equal(dependencies.ok, true);
  assert.equal(dependencies.install_attempted, false);
  assert.deepEqual(dependencies.missing_skills, []);
  assert.equal(fs.existsSync(path.join(workflow, '.legacy-kfc')), false);
  assert.equal(fs.existsSync(path.join(workflow, '.kfc')), true);
});
