const assert = require("assert");
const { execFileSync } = require("child_process");
const fs = require("fs");
const os = require("os");
const path = require("path");
const test = require("node:test");

const kitRoot = path.resolve(__dirname, "..");
const routerScript = path.join(kitRoot, "kfc-flow-router", "scripts", "kfc.js");
const hookHelperScript = path.join(kitRoot, "kfc-hook-helper", "scripts", "kfc-hook-helper.js");

function tempHome() {
  return fs.mkdtempSync(path.join(os.tmpdir(), "kfc-home-"));
}

function runJson(script, args, options = {}) {
  const stdout = execFileSync(process.execPath, [script, ...args], {
    cwd: kitRoot,
    env: { ...process.env, HOME: options.home || tempHome() },
    encoding: "utf8",
    timeout: 10000,
    input: options.input || undefined,
  });
  return JSON.parse(stdout);
}

function runText(script, args, options = {}) {
  return execFileSync(process.execPath, [script, ...args], {
    cwd: kitRoot,
    env: { ...process.env, HOME: options.home || tempHome() },
    encoding: "utf8",
    timeout: 10000,
    input: options.input || undefined,
  });
}

function emitHook(prompt) {
  return runJson(hookHelperScript, ["emit", "--agent", "codex", "--event", "UserPromptSubmit"], {
    home: tempHome(),
    input: JSON.stringify({ prompt }),
  });
}

function tempWorkflowRoot() {
  return fs.mkdtempSync(path.join(os.tmpdir(), "kfc-workflow-"));
}

function installFakeSkills(home, skillNames) {
  for (const skillName of skillNames) {
    const skillDir = path.join(home, ".codex", "skills", skillName);
    fs.mkdirSync(skillDir, { recursive: true });
    fs.writeFileSync(path.join(skillDir, "SKILL.md"), `---\nname: ${skillName}\n---\n# ${skillName}\n`);
  }
}

function completeNextStep(home, root, workflowId, purpose) {
  const continued = runJson(routerScript, [
    "continue",
    "--root", root,
    "--workflow-id", workflowId,
    "--skip-install",
  ], { home });
  assert.equal(continued.ok, true, JSON.stringify(continued, null, 2));
  const outputPath = path.join(root, continued.suggested_output_path);
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, `# ${continued.next_step.step_id}\n\n${purpose}\n`);
  const completed = runJson(routerScript, [
    "complete",
    "--root", root,
    "--workflow-id", workflowId,
    "--output-path", outputPath,
    "--purpose", purpose,
  ], { home });
  assert.equal(completed.ok, true, JSON.stringify(completed, null, 2));
  return { continued, completed, outputPath };
}

test("steps schema documents required fields and uses the user-level registry path", () => {
  const home = tempHome();
  const result = runJson(routerScript, ["steps", "schema"], { home });

  assert.equal(result.ok, true);
  assert.equal(result.command, "steps schema");
  assert.equal(result.registry_path, path.join(home, ".config", "kfc-plugin", "step-registry.json"));
  assert.deepEqual(result.required_for_user_added, ["stage", "step_id", "default_worker", "output_purpose"]);
  assert(result.template.fields.stage.description.includes("系统内置阶段"));
  assert(result.template.fields.position.description.includes("before"));
});

test("steps add writes only through CLI and catalog consumes effective user-added steps", () => {
  const home = tempHome();

  const preview = runJson(routerScript, [
    "steps",
    "add",
    "--stage", "development-execution",
    "--step", "ai_review",
    "--title", "AI Review",
    "--default-worker", "kfc-worker-code-review",
    "--candidate-workers", "kfc-worker-code-review,kfc-worker-security-review",
    "--output-purpose", "记录 AI 代码复核结果。",
    "--after", "development_record",
  ], { home });
  assert.equal(preview.ok, true);
  assert.equal(preview.applied, false);
  assert.equal(preview.preview.step.source, "user_added");

  const applied = runJson(routerScript, [
    "steps",
    "add",
    "--stage", "development-execution",
    "--step", "ai_review",
    "--title", "AI Review",
    "--default-worker", "kfc-worker-code-review",
    "--candidate-workers", "kfc-worker-code-review,kfc-worker-security-review",
    "--output-purpose", "记录 AI 代码复核结果。",
    "--after", "development_record",
    "--apply",
  ], { home });
  assert.equal(applied.ok, true);
  assert.equal(applied.applied, true);

  const list = runJson(routerScript, ["steps", "list", "--stage", "development-execution"], { home });
  const added = list.steps.find((step) => step.step_id === "ai_review");
  assert(added);
  assert.equal(added.source, "user_added");
  assert.equal(added.default_worker, "kfc-worker-code-review");
  assert.equal(added.order_source, "user");

  const catalog = runJson(routerScript, ["catalog", "--stage", "development-execution"], { home });
  assert(catalog.steps.some((step) => step.step_id === "ai_review"));
  assert(catalog.available_skills.some((skill) => skill.name === "kfc-worker-code-review"));
});

test("steps update overrides system fields and reset restores the system step", () => {
  const home = tempHome();

  const updated = runJson(routerScript, [
    "steps",
    "update",
    "--stage", "development-execution",
    "--step", "development_record",
    "--default-worker", "kfc-worker-development-record",
    "--candidate-workers", "kfc-worker-development-record,deep-crew-issue-updater",
    "--output-purpose", "记录开发结果，并在用户明确要求时写入 issue。",
    "--apply",
  ], { home });
  assert.equal(updated.ok, true);
  assert.equal(updated.applied, true);

  const list = runJson(routerScript, ["steps", "list", "--stage", "development-execution"], { home });
  const overridden = list.steps.find((step) => step.step_id === "development_record");
  assert.equal(overridden.source, "user_override");
  assert(overridden.overridden_fields.includes("candidate_workers"));
  assert(overridden.candidate_workers.includes("deep-crew-issue-updater"));

  const reset = runJson(routerScript, ["steps", "reset", "--stage", "development-execution", "--step", "development_record"], { home });
  assert.equal(reset.ok, true);
  assert.equal(reset.removed, true);

  const after = runJson(routerScript, ["steps", "list", "--stage", "development-execution"], { home });
  const restored = after.steps.find((step) => step.step_id === "development_record");
  assert.equal(restored.source, "system");
  assert(!restored.candidate_workers.includes("deep-crew-issue-updater"));
});

test("steps remove rejects system steps and only removes user-added steps", () => {
  const home = tempHome();

  const rejected = runJson(routerScript, ["steps", "remove", "--stage", "development-execution", "--step", "development_record"], { home });
  assert.equal(rejected.ok, false);
  assert.equal(rejected.reason, "cannot_remove_system_step");

  runJson(routerScript, [
    "steps",
    "add",
    "--stage", "development-execution",
    "--step", "temporary_review",
    "--default-worker", "kfc-worker-code-review",
    "--output-purpose", "临时复核。",
    "--apply",
  ], { home });
  const removed = runJson(routerScript, ["steps", "remove", "--stage", "development-execution", "--step", "temporary_review"], { home });
  assert.equal(removed.ok, true);
  assert.equal(removed.removed, true);
});

test("continue uses user-added effective steps during workflow progression", () => {
  const home = tempHome();
  const root = tempWorkflowRoot();

  runJson(routerScript, [
    "steps",
    "add",
    "--stage", "development-execution",
    "--step", "local_preflight",
    "--default-worker", "local-preflight-skill",
    "--output-purpose", "记录本地预检查结果。",
    "--before", "tdd_execution",
    "--apply",
  ], { home });

  runJson(routerScript, [
    "init",
    "--root", root,
    "--workflow-id", "custom-step-flow",
    "--title", "Custom Step Flow",
    "--stage", "development-execution",
  ], { home });

  const continued = runJson(routerScript, [
    "continue",
    "--root", root,
    "--workflow-id", "custom-step-flow",
    "--skip-install",
  ], { home });

  assert.equal(continued.ok, true);
  assert.equal(continued.current_stage, "development-execution");
  assert.equal(continued.next_step.step_id, "local_preflight");
  assert.equal(continued.selected_skill, "local-preflight-skill");
  assert.equal(continued.active_step_session.step_id, "local_preflight");
});

test("steps validate rejects duplicate user step entries instead of merging order-dependent data", () => {
  const home = tempHome();
  const registryPath = path.join(home, ".config", "kfc-plugin", "step-registry.json");
  fs.mkdirSync(path.dirname(registryPath), { recursive: true });
  fs.writeFileSync(registryPath, JSON.stringify({
    version: 1,
    steps: [
      {
        stage: "development-execution",
        step_id: "development_record",
        output_purpose: "first override",
      },
      {
        stage: "development-execution",
        step_id: "development_record",
        output_purpose: "second override",
      },
    ],
  }, null, 2));

  const result = runJson(routerScript, ["steps", "validate"], { home });
  assert.equal(result.ok, false);
  assert(result.validation.errors.some((error) => error.code === "duplicate_user_step_entry"));
});

test("mark-code-change invalidates earlier quality gate outputs before closeout", () => {
  const home = tempHome();
  const root = tempWorkflowRoot();
  const workflowId = "quality-flow";
  installFakeSkills(home, [
    "kfc-worker-code-review",
    "kfc-worker-security-review",
  ]);

  runJson(routerScript, [
    "init",
    "--root", root,
    "--workflow-id", workflowId,
    "--title", "Quality Flow",
    "--stage", "test-and-selftest",
  ], { home });

  for (const purpose of [
    "automated verification before code change",
    "runtime selftest before code change",
    "code review before code change",
    "code review before code change",
    "security review before code change",
    "review readiness before code change",
  ]) {
    completeNextStep(home, root, workflowId, purpose);
  }

  const cleanBeforeChange = runJson(routerScript, ["closeout-check", "--root", root, "--workflow-id", workflowId], { home });
  assert.equal(cleanBeforeChange.needs_closeout, false);
  assert.deepEqual(cleanBeforeChange.pending_quality_gates, []);

  const marked = runJson(routerScript, [
    "mark-code-change",
    "--root", root,
    "--workflow-id", workflowId,
    "--event", "test",
    "--tool-name", "test",
  ], { home });
  assert.equal(marked.ok, true);

  const closeout = runJson(routerScript, [
    "closeout-check",
    "--root", root,
    "--workflow-id", workflowId,
    "--prepare",
  ], { home });
  assert.equal(closeout.needs_closeout, true);
  assert.deepEqual(closeout.pending_quality_gates, [
    "automated_verification",
    "runtime_selftest",
    "code_review",
    "security_review",
    "review_readiness_packaging",
  ]);
  assert.equal(closeout.next_quality_gate_step.step_id, "automated_verification");
  assert.equal(closeout.current_stage, "test-and-selftest");
  assert.equal(closeout.current_step_index, 0);
});

test("guarded KFC commands report unstable state and doctor clears safe temporary files", () => {
  const home = tempHome();
  const root = tempWorkflowRoot();
  const workflowId = "doctor-flow";

  runJson(routerScript, [
    "init",
    "--root", root,
    "--workflow-id", workflowId,
    "--title", "Doctor Flow",
    "--stage", "development-execution",
  ], { home });

  const statePath = path.join(root, ".kfc", "workflows", workflowId, "workflow-state.json");
  const tmpPath = `${statePath}.tmp`;
  fs.copyFileSync(statePath, tmpPath);

  const blocked = runJson(routerScript, ["current", "--root", root], { home });
  assert.equal(blocked.ok, false);
  assert.equal(blocked.reason, "unstable_kfc_state");
  assert.equal(blocked.next_required_action, "run_doctor_then_retry_original_command");
  assert(blocked.state_stability.issues.some((issue) => issue.code === "workflow_state_tmp_exists"));

  const doctor = runJson(routerScript, ["doctor", "--root", root, "--fix"], { home });
  assert.equal(doctor.ok, true);
  assert(doctor.fixed.some((item) => item.action === "removed_tmp_file"));
  assert.equal(fs.existsSync(tmpPath), false);

  const current = runJson(routerScript, ["current", "--root", root], { home });
  assert.equal(current.ok, true);
});

test("hook prompt names /kfc as the skill entrypoint and rejects shell or MCP entrypoints", () => {
  const result = emitHook("帮我修复这个 bug，并补测试");
  const context = result.hookSpecificOutput.additionalContext;

  assert(context.includes("/kfc <original user request>"));
  assert(context.includes("installed `kfc` skill entrypoint"));
  assert(context.includes("Do not use shell commands"));
  assert(context.includes("MCP routers"));
  assert(context.includes("project-local commands"));
  assert(context.includes("direct route tools"));
  assert(context.includes("record-user-decision"));
  assert(context.includes("Preserve the user's instruction"));
});

test("hook PreToolUse blocks git commit by default and explains project opt-in", () => {
  const root = tempWorkflowRoot();
  const result = runJson(hookHelperScript, ["emit", "--agent", "codex", "--event", "PreToolUse"], {
    home: tempHome(),
    input: JSON.stringify({
      hook_event_name: "PreToolUse",
      cwd: root,
      tool_name: "functions.exec_command",
      tool_input: {
        cmd: "git commit -m test",
      },
    }),
  });

  assert.equal(result.decision, "block");
  assert(result.reason.includes("当前项目没有开启 AI 自动提交"));
  assert(result.reason.includes("正式项目或团队项目"));
  assert(result.reason.includes("允许 AI 自动提交"));
  assert(result.reason.includes("KFC_ALLOW_AI_GIT_COMMIT=true"));
});

test("hook PreToolUse allows git commit when project agent rules explicitly opt in", () => {
  const root = tempWorkflowRoot();
  fs.writeFileSync(path.join(root, "AGENTS.md"), "允许 AI 自动提交：是（仅限本练习/个人项目）\n");
  const stdout = runText(hookHelperScript, ["emit", "--agent", "codex", "--event", "PreToolUse"], {
    home: tempHome(),
    input: JSON.stringify({
      hook_event_name: "PreToolUse",
      cwd: root,
      tool_name: "functions.exec_command",
      tool_input: {
        cmd: "git commit -m test",
      },
    }),
  });

  assert.equal(stdout.trim(), "");
});

test("hook PostToolUse routes code-change markers to nested tool workdir before top-level cwd", () => {
  const home = tempHome();
  const topLevelRoot = tempWorkflowRoot();
  const toolRoot = tempWorkflowRoot();

  runJson(routerScript, [
    "init",
    "--root", topLevelRoot,
    "--workflow-id", "top-level-workflow",
    "--title", "Top Level Workflow",
    "--stage", "development-execution",
  ], { home });
  runJson(routerScript, [
    "init",
    "--root", toolRoot,
    "--workflow-id", "tool-workdir-workflow",
    "--title", "Tool Workdir Workflow",
    "--stage", "development-execution",
  ], { home });

  const stdout = runText(hookHelperScript, ["emit", "--agent", "codex", "--event", "PostToolUse"], {
    home,
    input: JSON.stringify({
      hook_event_name: "PostToolUse",
      cwd: topLevelRoot,
      tool_name: "Edit",
      tool_input: {
        workdir: toolRoot,
        file_path: path.join(toolRoot, "src", "demo.js"),
      },
    }),
  });
  assert.equal(stdout.trim(), "");

  const topLevelCloseout = runJson(routerScript, ["closeout-check", "--root", topLevelRoot], { home });
  const toolCloseout = runJson(routerScript, ["closeout-check", "--root", toolRoot], { home });

  assert.equal(topLevelCloseout.needs_closeout, false);
  assert.equal(toolCloseout.needs_closeout, true);
  assert.deepEqual(toolCloseout.pending_quality_gates, [
    "automated_verification",
    "runtime_selftest",
    "code_review",
    "security_review",
    "review_readiness_packaging",
  ]);
});

test("hook PostToolUse ignores writes confined to .kfc state", () => {
  const home = tempHome();
  const root = tempWorkflowRoot();

  runJson(routerScript, [
    "init",
    "--root", root,
    "--workflow-id", "kfc-state-write-flow",
    "--title", "KFC State Write Flow",
    "--stage", "development-execution",
  ], { home });

  const stdout = runText(hookHelperScript, ["emit", "--agent", "codex", "--event", "PostToolUse"], {
    home,
    input: JSON.stringify({
      hook_event_name: "PostToolUse",
      cwd: root,
      tool_name: "Edit",
      tool_input: {
        workdir: root,
        file_path: path.join(root, ".kfc", "workflows", "kfc-state-write-flow", "workflow-state.json"),
      },
    }),
  });
  assert.equal(stdout.trim(), "");

  const closeout = runJson(routerScript, ["closeout-check", "--root", root], { home });
  assert.equal(closeout.needs_closeout, false);
  assert.deepEqual(closeout.pending_quality_gates, []);
});

test("hook PostToolUse marks mixed KFC state and project writes as code changes", () => {
  const home = tempHome();
  const root = tempWorkflowRoot();

  runJson(routerScript, [
    "init",
    "--root", root,
    "--workflow-id", "mixed-write-flow",
    "--title", "Mixed Write Flow",
    "--stage", "development-execution",
  ], { home });

  const stdout = runText(hookHelperScript, ["emit", "--agent", "codex", "--event", "PostToolUse"], {
    home,
    input: JSON.stringify({
      hook_event_name: "PostToolUse",
      cwd: root,
      tool_name: "MultiEdit",
      tool_input: {
        workdir: root,
        edits: [
          { file_path: path.join(root, ".kfc", "workflows", "mixed-write-flow", "workflow-state.json") },
          { file_path: path.join(root, "src", "feature.js") },
        ],
      },
    }),
  });
  assert.equal(stdout.trim(), "");

  const closeout = runJson(routerScript, ["closeout-check", "--root", root], { home });
  assert.equal(closeout.needs_closeout, true);
  assert(closeout.pending_quality_gates.includes("automated_verification"));
});

test("recorded user manual pass clears only the selected current quality gate", () => {
  const home = tempHome();
  const root = tempWorkflowRoot();
  const workflowId = "manual-pass-flow";

  runJson(routerScript, [
    "init",
    "--root", root,
    "--workflow-id", workflowId,
    "--title", "Manual Pass Flow",
    "--stage", "test-and-selftest",
  ], { home });
  runJson(routerScript, ["mark-code-change", "--root", root, "--workflow-id", workflowId], { home });

  const recorded = runJson(routerScript, [
    "record-user-decision",
    "--root", root,
    "--workflow-id", workflowId,
    "--action", "manual-pass",
    "--step", "automated_verification",
    "--reason", "用户已人工验证通过自动化验证结果。",
  ], { home });
  assert.equal(recorded.ok, true);
  assert.equal(recorded.user_decision.action, "manual-pass");
  assert.equal(recorded.user_decision.source, "user_instruction");

  const closeout = runJson(routerScript, ["closeout-check", "--root", root, "--workflow-id", workflowId], { home });
  assert.equal(closeout.needs_closeout, true);
  assert(!closeout.pending_quality_gates.includes("automated_verification"));
  assert.deepEqual(closeout.pending_quality_gates, [
    "runtime_selftest",
    "code_review",
    "security_review",
    "review_readiness_packaging",
  ]);
});

test("recorded skip-gate applies only until the next code change", () => {
  const home = tempHome();
  const root = tempWorkflowRoot();
  const workflowId = "skip-gate-flow";

  runJson(routerScript, [
    "init",
    "--root", root,
    "--workflow-id", workflowId,
    "--title", "Skip Gate Flow",
    "--stage", "test-and-selftest",
  ], { home });
  runJson(routerScript, ["mark-code-change", "--root", root, "--workflow-id", workflowId], { home });
  const recorded = runJson(routerScript, [
    "record-user-decision",
    "--root", root,
    "--workflow-id", workflowId,
    "--action", "skip-gate",
    "--step", "security_review",
    "--reason", "当前项目没有 external quality scanner 接入，本轮不适用。",
  ], { home });
  assert.equal(recorded.user_decision.action, "skip-gate");

  const skipped = runJson(routerScript, ["closeout-check", "--root", root, "--workflow-id", workflowId], { home });
  assert(!skipped.pending_quality_gates.includes("security_review"));

  runJson(routerScript, ["mark-code-change", "--root", root, "--workflow-id", workflowId], { home });
  const afterNewChange = runJson(routerScript, ["closeout-check", "--root", root, "--workflow-id", workflowId], { home });
  assert(afterNewChange.pending_quality_gates.includes("security_review"));
});

test("recorded close-workflow ends active work and releases closeout", () => {
  const home = tempHome();
  const root = tempWorkflowRoot();
  const workflowId = "close-workflow-flow";
  installFakeSkills(home, ["kfc-worker-development-execution"]);

  runJson(routerScript, [
    "init",
    "--root", root,
    "--workflow-id", workflowId,
    "--title", "Close Workflow Flow",
    "--stage", "development-execution",
  ], { home });
  const continued = runJson(routerScript, [
    "continue",
    "--root", root,
    "--workflow-id", workflowId,
    "--skill", "kfc-worker-development-execution",
    "--skip-install",
  ], { home });
  assert(continued.active_step_session);
  runJson(routerScript, ["mark-code-change", "--root", root, "--workflow-id", workflowId], { home });

  const closed = runJson(routerScript, [
    "record-user-decision",
    "--root", root,
    "--workflow-id", workflowId,
    "--action", "close-workflow",
    "--reason", "用户人工验证成功，要求直接关闭当前工作流。",
  ], { home });
  assert.equal(closed.ok, true);
  assert.equal(closed.workflow_status, "completed");
  assert.equal(closed.user_decision.action, "close-workflow");

  const closeout = runJson(routerScript, ["closeout-check", "--root", root, "--workflow-id", workflowId], { home });
  assert.equal(closeout.needs_closeout, false);
  assert.equal(closeout.reason, "workflow_closed_by_user_instruction");

  const current = runJson(routerScript, ["current", "--root", root, "--workflow-id", workflowId], { home });
  assert.equal(current.active_step_session, null);
  assert.equal(current.workflow.status, "completed");
  assert.equal(current.workflow.user_decisions.at(-1).reason, "用户人工验证成功，要求直接关闭当前工作流。");

  const nextRoute = runJson(routerScript, [
    "route",
    "--root", root,
    "--material", "全新库存盘点报表需求，不关联已关闭的工作流。",
  ], { home });
  assert.equal(nextRoute.workflow_auto_initialized, true);
  assert.notEqual(nextRoute.workflow_id, workflowId);
});

test("hook PreToolUse reads project commit policy from nested tool workdir variants", () => {
  const variants = [
    (workdir) => ({ tool_input: { workdir, cmd: "git commit -m test" } }),
    (workdir) => ({ toolInput: { cwd: workdir, cmd: "git commit -m test" } }),
    (workdir) => ({ input: { workspace_root: workdir, cmd: "git commit -m test" } }),
    (workdir) => ({ tool_call: { name: "functions.exec_command", input: { root: workdir, cmd: "git commit -m test" } } }),
  ];

  for (const buildInput of variants) {
    const topLevelRoot = tempWorkflowRoot();
    const toolRoot = tempWorkflowRoot();
    fs.writeFileSync(path.join(toolRoot, "AGENTS.md"), "KFC_ALLOW_AI_GIT_COMMIT=true\n");

    const stdout = runText(hookHelperScript, ["emit", "--agent", "codex", "--event", "PreToolUse"], {
      home: tempHome(),
      input: JSON.stringify({
        hook_event_name: "PreToolUse",
        cwd: topLevelRoot,
        tool_name: "functions.exec_command",
        ...buildInput(toolRoot),
      }),
    });

    assert.equal(stdout.trim(), "");
  }
});
