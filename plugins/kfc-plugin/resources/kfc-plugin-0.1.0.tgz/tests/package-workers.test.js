const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const test = require('node:test');

test('包级移除先预览，再同步注销固定步骤、worker 和内置注册项，不写用户配置', (t) => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'kfc-package-workers-'));
  t.after(() => fs.rmSync(temp, { recursive: true, force: true }));
  const source = path.resolve(__dirname, '..');
  const root = path.join(temp, 'package');
  fs.cpSync(source, root, { recursive: true, filter: (p) => !['.git', '.kfc', 'tests', 'outputs'].includes(path.basename(p)) });
  const home = path.join(temp, 'user');
  fs.mkdirSync(home);
  const router = path.join(root, 'kfc-flow-router/scripts/kfc.js');
  const refs = path.join(root, 'kfc-flow-router/references');
  // 使用临时的外部 worker，验证机制不依赖某个公司产品名。
  const skill = 'fixture-external-worker';
  fs.appendFileSync(path.join(refs, 'stage-steps.yaml'), '\n  fixture-stage:\n    next_stage: null\n    default_steps:\n      - step_id: external_check\n        default_worker: ' + skill + '\n        candidate_workers:\n          - ' + skill + '\n        output_purpose: 测试外部检查。\n');
  fs.appendFileSync(path.join(refs, 'worker-catalog.yaml'), '\n  fixture-stage:\n    skills:\n      - name: ' + skill + '\n        summary: 临时外部检查。\n');
  const registryPath = path.join(refs, 'builtin-skill-registry.json');
  const registry = JSON.parse(fs.readFileSync(registryPath));
  registry.entries.push({ stage: 'fixture-stage', step_id: 'external_check', skill });
  fs.writeFileSync(registryPath, JSON.stringify(registry));
  const args = ['remove-skill', '--scope', 'package', '--stage', 'fixture-stage', '--step', 'external_check', '--skill', skill, '--remove-step'];
  const run = (extra = []) => JSON.parse(execFileSync(process.execPath, [router, ...args, ...extra], {
    env: { ...process.env, HOME: home, KFC_CONFIG_HOME: path.join(home, 'config') }, encoding: 'utf8',
  }));
  const before = fs.readFileSync(path.join(refs, 'stage-steps.yaml'), 'utf8');
  const preview = run();
  assert.equal(preview.applied, false);
  assert.equal(fs.readFileSync(path.join(refs, 'stage-steps.yaml'), 'utf8'), before);
  assert(preview.plan_hash);
  const applied = run(['--apply', '--plan', preview.plan_hash]);
  assert.equal(applied.applied, true);
  for (const name of ['stage-steps.yaml', 'worker-catalog.yaml', 'builtin-skill-registry.json']) {
    assert(!fs.readFileSync(path.join(refs, name), 'utf8').includes(skill), name);
  }
  assert.deepEqual(fs.readdirSync(home), []);
});
