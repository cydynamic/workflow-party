# KaleidoSphere (万花境)

> **The Core Repository & Origin.**
> _Infinite Patterns from Simple Elements._

This is the core repository of the next generation of **KaleidoSphere**.
KaleidoSphere is a Human-in-the-loop AI work operating layer. It provides a
durable work environment, project asset management, context recovery, and
capability routing without binding users to one Agent, workflow, or provider.

### 🌌 Naming

- **Sphere**: A bounded and durable AI work environment for user-level project
  assets, local context, capabilities, and recoverable state.
- **Kaleidoscope**: Simple, replaceable, composable units such as skills, CLI,
  MCP, providers, project rules, and local assets form adaptive work patterns.

### 🧠 Core Philosophy

- **Prism**: Refract user intent, project identity, local context, and available
  capabilities into an appropriate work environment rather than forcing every
  request through one fixed workflow.
- **Assetization**: Project identity, paths, replica relationships, and local
  context outlive a single conversation and support Agent switching.
- **Knowledge Sedimentation**: Associate reusable knowledge with suitable
  carriers without forcing transient process noise into project repositories.
- **Human in the Loop**: KaleidoSphere assists organization and delivery; it
  does not decide project classification, migration, publication, or capability
  selection on the user's behalf.

## 🛡️ Current Capabilities

### Project Asset Management

`project-distribution-manager` is the first KS capability. Its `ks` CLI owns
the user-level registry and supports workspace initialization, workspace
registration, project creation, existing Git-project registration, and listing.

```text
ks init
ks workspace add
ks workspace list
ks project create
ks project register
ks project list
```

`$KS_HOME` defaults to `~/.ks` on macOS and Linux, and `%USERPROFILE%\\.ks`
on Windows. Only the CLI may read or write it.

### Outputs

`outputs/` is the distributable artifact layer. It contains plugin areas for
Codex and Claude, a Power area for Kiro, agent-independent MCPs and skills.

> Platform artifacts are never prebuilt or guessed. They are created only when
> explicitly requested, through the target Agent's own plugin or Power creation
> capability.

See [Output Governance](docs/outputs.md).

## 🌌 Repository Architecture

```text
KaleidoSphere
├── cli/                  ks CLI
├── skills/               KS source capabilities
├── mcp/                  Future service integrations
├── docs/                 Design and maintenance documentation
├── outputs/              Distributable artifacts
└── $KS_HOME              User-level registry and recoverable state
```

## 🚀 Development Workspace

Managed projects may use an envelope that keeps the original repository and
KS-specific local context separate:

```text
<workspace>/<project-slug>/
├── repo/                    Original project repository
├── ks-context/              Local project context
├── .gitignore               Ignores repo/
└── .git/                    Local envelope history
```

The envelope is optional. KaleidoSphere itself is registered as a direct
repository layout.

## 🛠 Development

Run the automated tests:

```bash
npm test
```

For output, installation, synchronization, or packaging work, read
[Output Governance](docs/outputs.md) first.

[中文文档](README_CN.md)
